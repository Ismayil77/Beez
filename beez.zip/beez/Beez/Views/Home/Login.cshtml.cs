using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace Beez.Views.Home
{
    public class LoginModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
