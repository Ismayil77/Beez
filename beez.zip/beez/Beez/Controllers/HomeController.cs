using Beez.Models;
using Microsoft.AspNetCore.Mvc;

namespace Beez.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]
        public IActionResult Login([FromBody] LoginModel login)
        {
            if (login.Username == "captain" && login.Password == "saymyname")
                return Ok(); 

            return Unauthorized("Invalid username or password");
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
    }
}
