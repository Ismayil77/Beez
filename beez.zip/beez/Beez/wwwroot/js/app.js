let currentSongIndex = 0;
let player;
let filteredList = null;

const songs = [
    { title: 'Nillayo', youtubeId: '0fpZWj-1Bzg' },
    { title: 'Maiyya Yashoda', youtubeId: 'e-Ttv7H5ijI' },
    { title: 'kannodu', youtubeId: 'tS3q0ktFoLk' }, 
        { title: 'Neelambalin', youtubeId: 'vDGlGVtTsCg' },
        { title: 'Neerolam Mele Moodum', youtubeId: 'hyEEzrOM66U' },
        { title: 'Jiya Tui Chara', youtubeId: 'OoyGXlHsSZM' },
        { title: 'Por Mugham', youtubeId: 'OjJ3tZ801Vg' },
        { title: 'Santhamee Rathri', youtubeId: 'yOsZZBRau5U' },
        { title: 'Aaha Manoranjini', youtubeId: 'ih5pZDSx51I' },
        { title: 'Sawadeeka', youtubeId: 'RHEFxrSxGa4' },
        { title: 'Thimiru Kaattaadha Di', youtubeId: 'igidmYrFT-Y' },
        { title: 'Naa Ready', youtubeId: '3wDiqlTNlfQ' },
        { title: 'Vascodagama - Duet Version', youtubeId: 'ExWeCbaedY4' },
        { title: 'Killer On The Loose', youtubeId: 'zL4cULLyBJY' },
        { title: 'Ainvayi Ainvayi', youtubeId: 'pElk1ShPrcE' },
        { title: 'Agar Tum Saath Ho', youtubeId: 'xRb8hxwN5zc' },
        { title: 'Endhe Innum', youtubeId: '2hAfg4tjc-s' },
        { title: 'Sher Aaya Sher', youtubeId: 'M81wneSjQbA' },
        { title: 'Jhol', youtubeId: 't7hPHaVsFwo' },
        { title: 'Kun Faya Kun', youtubeId: 'T94PHkuydcw' },
        { title: 'Tainu Khabar Nahi', youtubeId: 'zFz3jK9Jt1Q' },
        { title: 'Mari Mari', youtubeId: 'e2U3N0U8eJw' },
        { title: 'Madhurame', youtubeId: 's8Y2p0H5x9M' },
        { title: 'Emitemitemo', youtubeId: 'kV9YzZ1r2FQ' },
        { title: 'Haan Ke Haan', youtubeId: 'n9Yx7Z3u5Lk' },
        { title: 'Telisiney Na Nuvvey', youtubeId: 'o3Y4pZ6t7WQ' },
        { title: 'Dhooram', youtubeId: 'l5Y8qZ9u2RM' },
        { title: 'Aankhon Mein Doob Jaane Ko', youtubeId: 'm6Y9rZ0v3SN' },
        { title: 'Oh Oh - The First Love of Tamizh', youtubeId: 'n7Y0sZ1w4TO' },
        { title: 'Marakkavillayae (Jersey)', youtubeId: 'o8Y1tZ2x5UP' },
        { title: 'Thaane Pookum', youtubeId: 'p9Y2uZ3y6VQ' },
        { title: 'Aankhon Se Batana', youtubeId: 'q0Y3vZ4z7WR' },
        { title: 'Enna Sona', youtubeId: 'r1Y4wZ5a8XS' },
        { title: 'Kadhalaada - Reprise', youtubeId: 's2Y5xZ6b9YT' },
        { title: 'Malargal Kaettaen', youtubeId: 't3Y6yZ7c0ZU' },
        { title: 'Pathikichu', youtubeId: 'u4Y7zZ8d1AV' },
        { title: 'Thoominnal', youtubeId: 'v5Y8aZ9e2BW' },
        { title: 'Ee Mazha Megham', youtubeId: 'w6Y9bZ0f3CX' },
        { title: 'Bulleya', youtubeId: 'x7Y0cZ1g4DY' },
        { title: 'Tum Se Hi', youtubeId: 'y8Y1dZ2h5EZ' },
        { title: 'Malang (Title Track)', youtubeId: 'z9Y2eZ3i6FA' },
        { title: 'Aabaad Barbaad', youtubeId: 'a0Y3fZ4j7GB' },
        { title: 'En Mizhi Poovil', youtubeId: 'b1Y4gZ5k8HC' },
        { title: 'Chillanjirukkiye', youtubeId: 'c2Y5hZ6l9ID' },
        { title: 'Water Packet', youtubeId: 'd3Y6iZ7m0JE' },
        { title: 'Katiya Karun', youtubeId: 'e4Y7jZ8n1KF' },
        { title: 'Lailakame', youtubeId: 'f5Y8kZ9o2LG' },
        { title: 'Taare Ginn', youtubeId: 'g6Y9lZ0p3MH' },
        { title: 'Chaand Baaliyan', youtubeId: 'h7Y0mZ1q4NI' },
        { title: 'Singa Kutty Bring on the Chaos', youtubeId: 'i8Y1nZ2r5OJ' },
        { title: 'Oru Vanchi Paattu', youtubeId: 'j9Y2oZ3s6PK' },
        { title: 'Hardum Humdum', youtubeId: 'k0Y3pZ4t7QL' },
        { title: 'Sajdaa', youtubeId: 'l1Y4qZ5u8RM' },
        { title: 'Samjhawan', youtubeId: 'm2Y5rZ6v9SN' },
        { title: 'Bolna', youtubeId: 'n3Y6sZ7w0TO' },
        { title: 'Pal', youtubeId: 'o4Y7tZ8x1UP' },
        { title: 'Ranjha', youtubeId: 'p5Y8uZ9y2VQ' },
        { title: 'Not A Teaser (Theme)', youtubeId: 'q6Y9vZ0z3WR' },
        { title: 'Shiva Thandavame', youtubeId: 'r7Y0wZ1a4XS' },      
];

// Initialize YouTube player
function onYouTubeIframeAPIReady() {
    player = new YT.Player('player', {
        height: '1',   // <-- Tiny size instead of '0'
        width: '1',    // <-- Tiny size instead of '0'
        videoId: songs[currentSongIndex].youtubeId,
        playerVars: {
            autoplay: 0, // Don't autoplay immediately
            controls: 0, // Hide controls
            modestbranding: 1,
            rel: 0
        },
        events: {
            'onStateChange': onPlayerStateChange,
        }
    });
}


// DOM Ready
document.addEventListener('DOMContentLoaded', () => {
    // Initialize event listeners
    document.getElementById('theme-toggle').addEventListener('click', toggleTheme);
    document.body.classList.add(localStorage.getItem('theme') || 'dark');

    renderSongs(songs);

    document.getElementById('play-pause-btn').addEventListener('click', togglePlayPause);
    document.getElementById('next-btn').addEventListener('click', nextSong);
    document.getElementById('prev-btn').addEventListener('click', prevSong);
    document.getElementById('mute-btn').addEventListener('click', toggleMute);
    document.getElementById('volume-slider').addEventListener('input', changeVolume);
    document.getElementById('search').addEventListener('input', filterSongs);
});


// Theme Toggle
function toggleTheme() {
    const body = document.body;
    const rays = document.querySelector('#rays');
    const icon = document.querySelector('#theme-icon');
  
    body.classList.toggle('dark');
    body.classList.toggle('light');
  
    const isLight = body.classList.contains('light');
    localStorage.setItem('theme', isLight ? 'light' : 'dark');
  
    if (isLight) {
      rays.style.opacity = '1';  // show rays (sun)
      rays.style.transform = 'scale(1)';
      icon.querySelector('circle').setAttribute('r', '5'); // smaller center
    } else {
      rays.style.opacity = '0';  // hide rays (moon)
      rays.style.transform = 'scale(0.5)';
      icon.querySelector('circle').setAttribute('r', '8'); // bigger moon circle
    }
  }
  

// Render song list
function renderSongs(songArray) {
    const songList = document.getElementById('song-list');
    songList.innerHTML = '';

    songArray.forEach((song, index) => {
        const songItem = document.createElement('div');
        songItem.classList.add('song-item');
        songItem.innerHTML = `
            <img src="https://img.youtube.com/vi/${song.youtubeId}/hqdefault.jpg" class="song-thumbnail" />
            <div class="song-title">${song.title}</div>
        `;
        songItem.addEventListener('click', () => {
            const actualIndex = songs.findIndex(s => s.youtubeId === song.youtubeId);
            if (actualIndex !== -1) {
                playSong(actualIndex);
            }
        });
        songList.appendChild(songItem);
    });
}

// Play selected song
function playSong(index) {
    currentSongIndex = index;
    if (player && player.loadVideoById) {
        player.loadVideoById(songs[currentSongIndex].youtubeId);

        const song = songs[currentSongIndex];

        // Standard UI
        document.getElementById('song-title').textContent = song.title;
        document.getElementById('song-thumbnail').src = `https://img.youtube.com/vi/${song.youtubeId}/hqdefault.jpg`;
        document.getElementById('player-container').classList.remove('hidden');
        document.getElementById('play-pause-btn').textContent = '⏸️ Pause';

        // Floating UI
        document.getElementById('floating-title').textContent = song.title;
        document.getElementById('floating-thumbnail').src = `https://img.youtube.com/vi/${song.youtubeId}/default.jpg`;
        document.getElementById('floating-player').classList.remove('hidden');
        document.getElementById('floating-play-pause').textContent = '⏸️';
    } else {
        console.error('YouTube Player not ready!');
    }
}


// Play/Pause toggle
function togglePlayPause() {
    const isPlaying = player.getPlayerState() === YT.PlayerState.PLAYING;
    if (isPlaying) {
        player.pauseVideo();
        document.getElementById('play-pause-btn').textContent = '▶️ Play';
        document.getElementById('floating-play-pause').textContent = '▶️';
    } else {
        player.playVideo();
        document.getElementById('play-pause-btn').textContent = '⏸️ Pause';
        document.getElementById('floating-play-pause').textContent = '⏸️';
    }
}


// Next/Prev
function nextSong() {
    currentSongIndex = (currentSongIndex + 1) % songs.length;
    playSong(currentSongIndex);
}

function prevSong() {
    currentSongIndex = (currentSongIndex - 1 + songs.length) % songs.length;
    playSong(currentSongIndex);
}

// Mute/Unmute
function toggleMute() {
    const isMuted = player.isMuted();

    if (isMuted) {
        player.unMute();
        player.setVolume(100);
        document.getElementById('volume-slider').value = 100;
        document.getElementById('floating-volume-slider').value = 100;
        document.getElementById('mute-btn').textContent = '🔊';
        document.getElementById('floating-mute').textContent = '🔊';
    } else {
        player.mute();
        player.setVolume(0);
        document.getElementById('volume-slider').value = 0;
        document.getElementById('floating-volume-slider').value = 0;
        document.getElementById('mute-btn').textContent = '🔇';
        document.getElementById('floating-mute').textContent = '🔇';
    }
}


// Volume
function changeVolume(e) {
    const volume = e.target.value;
    player.setVolume(volume);
    document.getElementById('volume-slider').value = volume;
    document.getElementById('floating-volume-slider').value = volume;
}


// Search filter
function filterSongs(e) {
    const query = e.target.value.toLowerCase();
    filteredList = songs.filter(song => song.title.toLowerCase().includes(query));
    renderSongs(filteredList);
}

// Auto next
function onPlayerStateChange(event) {
    if (event.data === YT.PlayerState.ENDED) {
        nextSong();
    }
}

