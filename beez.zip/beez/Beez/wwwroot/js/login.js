document.addEventListener('DOMContentLoaded', function () {
    const loginForm = document.getElementById('login-form');

    loginForm.addEventListener('submit', function (e) {
        e.preventDefault();

        let isValid = true;
        const email = document.getElementById('email');
        const password = document.getElementById('password');
        const emailError = document.getElementById('email-error');
        const passwordError = document.getElementById('password-error');
        const incorrectpasswordError = document.getElementById('incorrectpass-error');

        email.classList.remove('error');
        password.classList.remove('error');
        emailError.style.display = 'none';
        passwordError.style.display = 'none';
        incorrectpasswordError.style.display = 'none';

        if (email.value.trim() === '') {
            email.classList.add('error');
            emailError.style.display = 'block';
            isValid = false;
        }

        if (password.value.length < 6) {
            password.classList.add('error');
            passwordError.style.display = 'block';
            isValid = false;
        }

        if (isValid) {
            fetch('/Home/Login', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ username: email.value, password: password.value })
            })
                .then(response => {
                    if (response.ok) {
                        window.location.href = '/Home/Index';
                    } else {
                        alert('Login failed');
                    }
                })
                .catch(error => console.error('Login error:', error));
        }

    });

    // Bee trail code...
    document.addEventListener('mousemove', function (e) {
        const x = e.clientX;
        const y = e.clientY;
        const trail = document.createElement('div');
        trail.className = 'bee-trail';
        trail.style.left = x + 'px';
        trail.style.top = y + 'px';
        trail.style.width = '5px';
        trail.style.height = '5px';
        trail.style.background = Math.random() > 0.7 ? '#FF6B00' : '#FFC107';
        trail.style.borderRadius = Math.random() > 0.5 ? '50%' : '0%';
        document.body.appendChild(trail);

        setTimeout(() => {
            trail.style.opacity = '0.7';
            trail.style.transform = `translate(${Math.random() * 40 - 20}px, ${Math.random() * 40 - 20}px) scale(${Math.random() * 0.5 + 0.5})`;
            trail.style.transition = 'all 1s ease-out';
            setTimeout(() => trail.remove(), 1000);
        }, 10);
    });
});
